package sample;

public interface Observer {
    void update(String unit,double value);
}
